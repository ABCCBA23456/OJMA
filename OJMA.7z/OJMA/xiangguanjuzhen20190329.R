



   #pathway1
      
      a1<-read.csv(filePath,header=T)
      
      #  pathway2
        a2<-read.csv(filePath,header=T)
        p<-0
        for(j in 1:1000){
          for(i in 1:1000){
            
            if(a1[j]==a2[i]){
              p<-p+1
            }else{
              
            } 
            
          }
       
           }
          P[h1,h2]<-p/1000
          
  
    

  
    
    
    
    

