#Set the significance level
alfa<-0.05
#Number of individuals
repetition<-1000

    covbetaz<-matrix(c(0,0,0,0),ncol=2,byrow=T)
    wc<-matrix()
    covbetar<-matrix(c(0,0,0,0),ncol=2,byrow=T)
    covbetac<-c(0,0)
    betaz<-vector()
    stdz<-vector()
    w<-matrix(c(0,0,0,0),ncol=2,byrow=T)
    #filePath  the pathway of the correction matrix 
    CC<-read.csv(filePath,header=T)
    CC<-as.matrix(CC[,2:studyN1])
    b0<-matrix(c(0,0,0,0),nrow=2)
    c0<-matrix(rep(0,4*nrow(CC)),nrow=2)
    for(i in 1:nrow(CC)){
      b0<-matrix(c(0,0,0,0),nrow=2)
      for(j in 1:nrow(CC)){
        b<-CC[i,j]*diag(2)
        b0<-cbind(b0,b)
      }
      b0<-b0[,3:ncol(b0)]
      c0<-rbind(c0,b0)
      
    }
    C<-c0[3:nrow(c0),]
    #Generate study-level statistics
    for(j in 1:study[m]){
      #filePath the pathway of the data
      JMAdata<-read.csv(filePath,header=T)
      output<-summary(lm(Y~SNP+SNP*E+E,data=JMAdata),correlation=TRUE)
      corr<-output$correlation
      outputcoeff<-output$coefficients
      covbeta<-matrix(c(corr[2,2]*outputcoeff[2,2]*outputcoeff[2,2],corr[2,4]*outputcoeff[2,2]*outputcoeff[4,2],corr[4,2]*outputcoeff[2,2]*outputcoeff[4,2],corr[4,4]*outputcoeff[4,2]*outputcoeff[4,2]),ncol=2,byrow=T)
      beta1<-c(outputcoeff[2,1],outputcoeff[4,1])
      stdc<-c(outputcoeff[2,2],outputcoeff[4,2])
      betaz<-c(betaz,beta1)
      stdz<-c(stdz,stdc)
      ww<-diag(2)
      covbetaz<-bdiag(covbetaz,covbeta)
      w<-rbind(w,ww)
    }
    
    covbetaz<-covbetaz[3:nrow(covbetaz),3:nrow(covbetaz)]
    w<-w[3:nrow(w),]
    covbetaz<-as.matrix(covbetaz)
    ev <- eigen(covbetaz)
    
    sqrtcovbetaz<-ev$vectors%*%diag(sqrt(ev$values))%*%t(ev$vectors)
    omiga<-sqrtcovbetaz%*%C%*%sqrtcovbetaz
    alfamid<-t(w)%*%solve(omiga)%*%betaz
    alfa<-solve(t(w)%*%solve(omiga)%*%w)%*%alfamid
    covalfa<-solve(t(w)%*%solve(omiga)%*%w)
    #produce the tests of interaction or SNP and SNP-interaction statistics
    SJMA[l]<-(alfa[2]^2)/covalfa[2,2]
    SJMA2[l]<-t(alfa)%*%solve(covalfa)%*%alfa
    
